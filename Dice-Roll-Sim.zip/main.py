# Python Dice Rol Simulator Assignment

import random

# Main Menu Loop
loadMenu = True
while loadMenu:

  print("\nDICE ROLL SIMULATOR MENU")
  print("1: Roll Dice Once")
  print("2: Roll Dice 5 Times")
  print("3: Roll Dice 'n' Times")
  print("4: Roll Dice Until Snake Eyes")
  print("5: EXIT")

  # Get Menu Selection Number From The User
  select = input("Enter Seletion (1-5): ")

  # If Statements Based Off User Input
  if (select == "1"):
    print("\nRolling Dice Once")
    # Set Loop
    r = 0
    while r < 1:
      # Roll Dice
      dOne = int(random.randrange(1, 7))
      dTwo = int(random.randrange(1, 7))
      total = dOne + dTwo
      print(str(dOne) + " - " + str(dTwo) + " (Total = " + str(total) + ")")
      r += 1
  elif (select == "2"):
    print("\nRolling Dice 5 Times")
    # Set Loop
    r = 0
    while r < 5:
      # Roll Dice
      dOne = int(random.randrange(1, 7))
      dTwo = int(random.randrange(1, 7))
      total = dOne + dTwo
      print(str(dOne) + " - " + str(dTwo) + " (Total = " + str(total) + ")")
      r += 1
  elif (select == "3"):
    print("\nRolling Dice 'n' Times")
    rolls = int(input("How many dice rolls do you want? : "))
    # Set Loop
    r = 0
    while r < rolls:
      # Roll Dice
      dOne = int(random.randrange(1, 7))
      dTwo = int(random.randrange(1, 7))
      total = dOne + dTwo
      print(str(dOne) + " - " + str(dTwo) + " (Total = " + str(total) + ")")
      r += 1
  elif (select == "4"):
    print("\nRolling Dice Until Snake Eyes")
    # Set Loop
    r = 0
    while r < 1:
      # Roll Dice
      dOne = int(random.randrange(1, 7))
      dTwo = int(random.randrange(1, 7))
      total = dOne + dTwo
      print(str(dOne) + " - " + str(dTwo) + " (Total = " + str(total) + ")")
      if (dOne + dTwo == 2):
        r += 1
  elif (select == "5"):
    print("\nEXITING")
    loadMenu = False


